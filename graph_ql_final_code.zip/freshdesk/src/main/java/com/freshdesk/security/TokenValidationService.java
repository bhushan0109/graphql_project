package com.freshdesk.security;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ServerWebExchange;

@Service
public class TokenValidationService {
    private static final String BEARER_PREFIX = "Bearer ";

    public void validateToken(Object context) {
        String token = extractTokenFromContext(context);
        if (token == null) {
            throw new RuntimeException("Authorization header is missing");
        }
        validateTokenWithGoogle(token);
    }

    private String extractTokenFromContext(Object context) {
        if (context instanceof ServerWebExchange) {
            return extractTokenFromServerWebExchange((ServerWebExchange) context);
        }
        return null;
    }

    private String extractTokenFromServerWebExchange(ServerWebExchange exchange) {
        String authHeader = exchange.getRequest().getHeaders().getFirst(HttpHeaders.AUTHORIZATION);
        if (authHeader != null && authHeader.startsWith(BEARER_PREFIX)) {
            return authHeader.substring(BEARER_PREFIX.length());
        }
        return null;
    }

    private void validateTokenWithGoogle(String token) {
        // Implement token validation logic here
    }
}
