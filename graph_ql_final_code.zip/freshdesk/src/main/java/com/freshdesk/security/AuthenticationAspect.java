package com.freshdesk.security;

import java.io.IOException;

//AuthenticationAspect.java
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.freshdesk.exceptions.CustomException;
import com.freshdesk.exceptions.ErrorCode;

import jakarta.servlet.http.HttpServletRequest;

@Aspect
@Component
public class AuthenticationAspect {

	@Autowired
	private HttpServletRequest request;

	@Autowired
	private HeaderValidator headerValidator;

	@Around("@annotation(com.freshdesk.security.RequiresAuthentication)")
	public Object enforceAuthentication(ProceedingJoinPoint joinPoint) throws Throwable {
		
		 String methodName = getMethodName(joinPoint);
	        System.out.println("Executing method: " + methodName);
		// Check if the user is authenticated and has the required role
		boolean isAuthenticated = checkAuthentication();
		if (!isAuthenticated) {
			return "You need to be authenticated to access this resource";
		}

		return joinPoint.proceed();
	}

	private boolean checkAuthentication() throws IOException {

		String authHeader = request.getHeader("Authorization");
		System.out.println("authHeader==> " + authHeader);
		if (authHeader == null || !headerValidator.validateAuthorizationHeader(authHeader)) {
			throw new CustomException(ErrorCode.INVALID_AUTHORIZATION, ErrorCode.INVALID_AUTHORIZATION.getMessage());
			//return false;
		}
		return true;
	}
	 private String getMethodName(ProceedingJoinPoint joinPoint) {
	        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
	        return signature.getName();
	    }
}
