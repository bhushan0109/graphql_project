package com.freshdesk.security;

import org.springframework.stereotype.Component;

@Component
public class HeaderValidator {

	// This method validates the Authorization header
	public boolean validateAuthorizationHeader(String authHeader) {
		if (authHeader == null || !authHeader.startsWith("Bearer ")) {
			return false; // Invalid Authorization header format
		}

		// Extract token from Authorization header
		String token = authHeader.substring(7); // Remove "Bearer " prefix
		return !token.isEmpty();
	}
}

