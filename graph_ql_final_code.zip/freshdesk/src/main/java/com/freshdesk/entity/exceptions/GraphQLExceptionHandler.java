package com.freshdesk.entity.exceptions;

import java.util.HashMap;
import java.util.Map;

import org.springframework.graphql.execution.DataFetcherExceptionResolverAdapter;
import org.springframework.stereotype.Component;

import graphql.GraphQLError;
import graphql.GraphqlErrorBuilder;
import graphql.schema.DataFetchingEnvironment;

@Component
public class GraphQLExceptionHandler extends DataFetcherExceptionResolverAdapter {

    @Override
    protected GraphQLError resolveToSingleError(Throwable ex, DataFetchingEnvironment env) {
        if (ex instanceof CustomException) {
            CustomException customException = (CustomException) ex;
            Map<String, Object> extensions = new HashMap<>();
            extensions.put("errorCode", customException.getErrorCode().getCode());
            return GraphqlErrorBuilder.newError()
                    .message(customException.getMessage())
                    .extensions(extensions)
                    .build();
        } else {
            // Handle all other exceptions as internal server errors
            return GraphqlErrorBuilder.newError()
                    .message("Internal server error. Please try again later.")
                    .build();
        }
    }
}
