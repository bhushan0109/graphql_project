package com.freshdesk.entity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.freshdesk.entity.CmsUsers;

public interface CmsUsersRepository extends JpaRepository<CmsUsers, Long> {
}
