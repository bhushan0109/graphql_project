package com.freshdesk.entity.exceptions;


public enum ErrorCode {
    GROUP_NOT_FOUND(1001, "Group not found with id"),
    USER_NOT_FOUND(1002, "User not found with id"),
    VALIDATION_ERROR(1003, "Validation error"),
    EXCEPTION_OCCURRED(1004, "Something went wrong, Please try after sometime !!");

    private final int code;
    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}

