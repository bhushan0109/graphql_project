package com.freshdesk.config.logconfig;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import graphql.ExecutionResult;
import graphql.execution.instrumentation.InstrumentationContext;
import graphql.execution.instrumentation.SimpleInstrumentation;
import graphql.execution.instrumentation.SimpleInstrumentationContext;
import graphql.execution.instrumentation.parameters.InstrumentationExecutionParameters;

@Component
final class RequestLoggingInstrumentation extends SimpleInstrumentation {
	private static final ObjectMapper objectMapper = new ObjectMapper();
	private static final Logger logger = LoggerFactory.getLogger(RequestLoggingInstrumentation.class);

	@Override
	public InstrumentationContext<ExecutionResult> beginExecution(InstrumentationExecutionParameters parameters) {
		long startMillis = System.currentTimeMillis();
		var executionId = parameters.getExecutionInput().getExecutionId();

		if (logger.isInfoEnabled()) {
			logger.info("GraphQL execution {} started", executionId);

			var query = parameters.getQuery();
			logger.info("[{}] query: {}", executionId, query);
			if (parameters.getVariables() != null && !parameters.getVariables().isEmpty()) {
				logger.info("[{}] variables: {}", executionId, parameters.getVariables());
			}
		}

		return new SimpleInstrumentationContext<>() {
			@Override
			public void onCompleted(ExecutionResult executionResult, Throwable t) {
				if (logger.isInfoEnabled()) {
					long endMillis = System.currentTimeMillis();

					if (t != null) {
						logger.info("GraphQL execution {} failed: {}", executionId, t.getMessage(), t);
					} else {
						try {
							var resultMap = executionResult.toSpecification();
//							var resultJSON = objectMapper.writeValueAsString(resultMap).replace("\n", "\\n");
							
							logger.info ("result==>"+ objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(resultMap));
							
							
							logger.info("[{}] completed in {}ms", executionId, endMillis - startMillis);
//							logger.info("[{}] result: {}", executionId, resultJSON);
						} catch (Exception e) {
							logger.error("Failed to convert execution result to JSON for execution {}: {}", executionId,
									e.getMessage(), e);
						}
					}
				}
			}
		};
	}
}