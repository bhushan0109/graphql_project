//package com.freshdesk.config;
//
//
//import java.io.IOException;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//
//import com.freshdesk.service.CmsUsersResolver;
//import com.freshdesk.service.GroupsResolver;
//
//import graphql.GraphQL;
//import graphql.schema.GraphQLSchema;
//import graphql.schema.idl.RuntimeWiring;
//import graphql.schema.idl.SchemaGenerator;
//import graphql.schema.idl.SchemaParser;
//import graphql.schema.idl.TypeDefinitionRegistry;
//import jakarta.annotation.PostConstruct;
//
//@Configuration
//public class GraphQLConfiguration {
//
//    private GraphQL graphQL;
//
//    @Bean
//    public GraphQL graphQL() {
//        return graphQL;
//    }
//
//    @PostConstruct
//    public void init() throws IOException {
//        String schema = new String(Files.readAllBytes(Paths.get("src/main/resources/schema.graphqls")));
//        TypeDefinitionRegistry typeRegistry = new SchemaParser().parse(schema);
//        RuntimeWiring wiring = buildWiring();
//        GraphQLSchema graphQLSchema = new SchemaGenerator().makeExecutableSchema(typeRegistry, wiring);
//        this.graphQL = GraphQL.newGraphQL(graphQLSchema).build();
//    }
//
//    private RuntimeWiring buildWiring() {
//
//        return RuntimeWiring.newRuntimeWiring()
//                .type("Query", typeWiring -> typeWiring
//                        .dataFetcher("getAllCmsUsers", env -> cmsUsersResolver.getAllCmsUsers())
//                        .dataFetcher("getCmsUserById", env -> cmsUsersResolver.getCmsUserById(env.getArgument("id")))
//                        .dataFetcher("getAllGroups", env -> groupsResolver.getAllGroups())
//                        .dataFetcher("getGroupById", env -> groupsResolver.getGroupById(env.getArgument("id"))))
//                .type("Mutation", typeWiring -> typeWiring
//                        .dataFetcher("createCmsUser", env -> cmsUsersResolver.createCmsUser(
//                                env.getArgument("name"),
//                                env.getArgument("email"),
//                                env.getArgument("isActive"),
//                                env.getArgument("groupId")))
//                        .dataFetcher("updateCmsUser", env -> cmsUsersResolver.updateCmsUser(
//                                env.getArgument("id"),
//                                env.getArgument("name"),
//                                env.getArgument("email"),
//                                env.getArgument("isActive"),
//                                env.getArgument("groupId")))
//                        .dataFetcher("deleteCmsUser", env -> cmsUsersResolver.deleteCmsUser(env.getArgument("id")))
//                        .dataFetcher("createGroup", env -> groupsResolver.createGroup(
//                                env.getArgument("name"),
//                                env.getArgument("archive"),
//                                env.getArgument("groupsPermissionId")))
//                        .dataFetcher("updateGroup", env -> groupsResolver.updateGroup(
//                                env.getArgument("id"),
//                                env.getArgument("name"),
//                                env.getArgument("archive"),
//                                env.getArgument("groupsPermissionId")))
//                        .dataFetcher("deleteGroup", env -> groupsResolver.deleteGroup(env.getArgument("id"))))
//                .build();
//    }
//}
//
