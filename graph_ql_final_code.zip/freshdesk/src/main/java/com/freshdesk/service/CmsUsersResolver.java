package com.freshdesk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.freshdesk.entity.CmsUsers;
import com.freshdesk.entity.Groups;
import com.freshdesk.entity.repository.CmsUsersRepository;
import com.freshdesk.entity.repository.GroupsRepository;

@Component
public class CmsUsersResolver {

	@Autowired
	private CmsUsersRepository cmsUsersRepository;

	@Autowired
	private GroupsRepository groupsRepository;

	public List<CmsUsers> getAllCmsUsers() {
		return cmsUsersRepository.findAll();
	}

	public Optional<CmsUsers> getCmsUserById(Long id) {
		return cmsUsersRepository.findById(id);
	}

	public CmsUsers createCmsUser(String name, String email, Boolean isActive, Long groupId) {
		Groups group = groupsRepository.findById(groupId).orElseThrow();
		CmsUsers cmsUser = new CmsUsers(name, email, isActive, group);
		return cmsUsersRepository.save(cmsUser);
	}

	public CmsUsers updateCmsUser(Long id, String name, String email, Boolean isActive, Long groupId) {
		CmsUsers cmsUser = cmsUsersRepository.findById(id).orElseThrow();
		if (name != null)
			cmsUser.setName(name);
		if (email != null)
			cmsUser.setEmail(email);
		if (isActive != null)
			cmsUser.setIsActive(isActive);
		if (groupId != null) {
			Groups group = groupsRepository.findById(groupId).orElseThrow();
			cmsUser.setGroups(group);
		}
		return cmsUsersRepository.save(cmsUser);
	}

	public boolean deleteCmsUser(Long id) {
		cmsUsersRepository.deleteById(id);
		return !cmsUsersRepository.existsById(id);
	}
}
