package com.freshdesk.service;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.freshdesk.entity.Groups;
import com.freshdesk.entity.GroupsPermissions;
import com.freshdesk.repository.GroupsPermissionsRepository;
import com.freshdesk.repository.GroupsRepository;

@Component
public class GroupsResolver {

    @Autowired
    private GroupsRepository groupsRepository;

    @Autowired
    private GroupsPermissionsRepository groupsPermissionsRepository;

    public List<Groups> getAllGroups() {
        return groupsRepository.findAll();
    }

    public Optional<Groups> getGroupById(Long id) {
        return groupsRepository.findById(id);
    }

    public Groups createGroup(String name, Boolean archive, Long groupsPermissionId) {
        GroupsPermissions groupsPermissions = groupsPermissionsRepository.findById(groupsPermissionId).orElseThrow();
        Groups group = new Groups(name, archive, groupsPermissions);
        return groupsRepository.save(group);
    }

    public Groups updateGroup(Long id, String name, Boolean archive, Long groupsPermissionId) {
        Groups group = groupsRepository.findById(id).orElseThrow();
        if (name != null) group.setName(name);
        if (archive != null) group.setArchive(archive);
        if (groupsPermissionId != null) {
            GroupsPermissions groupsPermissions = groupsPermissionsRepository.findById(groupsPermissionId).orElseThrow();
            group.setGroupsPermissions(groupsPermissions);
        }
        return groupsRepository.save(group);
    }

    public boolean deleteGroup(Long id) {
        groupsRepository.deleteById(id);
        return !groupsRepository.existsById(id);
    }
}
