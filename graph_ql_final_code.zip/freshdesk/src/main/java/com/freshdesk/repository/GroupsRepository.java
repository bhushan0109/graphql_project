package com.freshdesk.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.freshdesk.entity.Groups;

public interface GroupsRepository extends JpaRepository<Groups, Long> {
}
