package com.freshdesk.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.freshdesk.entity.CmsUsers;
import com.freshdesk.entity.Groups;
import com.freshdesk.exceptions.CustomException;
import com.freshdesk.exceptions.ErrorCode;
import com.freshdesk.repository.CmsUsersRepository;
import com.freshdesk.repository.GroupsRepository;
import com.freshdesk.service.CmsUsersResolver;

@Controller
public class CmsUsersController {

	@Autowired
	private CmsUsersRepository cmsUsersRepository;

	@Autowired
	CmsUsersResolver cmsUsersResolver;

	@QueryMapping
	public List<CmsUsers> getAllCmsUsers() {
		return cmsUsersRepository.findAll();
	}

	@QueryMapping
	public Optional<CmsUsers> getCmsUserById(@Argument Long id) {
		return cmsUsersRepository.findById(id);
	}

	@MutationMapping
	public CmsUsers createCmsUser(@Argument String name, @Argument String email, @Argument Boolean isActive,
			@Argument Long groupId) {
		CmsUsers cmsUser = cmsUsersResolver.createCmsUser(name, email, isActive, groupId);
		return cmsUser;
	}

	@MutationMapping
	public CmsUsers updateCmsUser(@Argument Long id, @Argument String name, @Argument String email,
			@Argument Boolean isActive, @Argument Long groupId) {
		CmsUsers updateCmsUser = cmsUsersResolver.updateCmsUser(id, name, email, isActive, groupId);
		return updateCmsUser;
	}

	@MutationMapping
	public boolean deleteCmsUser(@Argument Long id) {
		if (!cmsUsersRepository.existsById(id)) {
			throw new CustomException(ErrorCode.USER_NOT_FOUND, ErrorCode.USER_NOT_FOUND.getMessage() + " _" + id);
		}
		cmsUsersRepository.deleteById(id);
		return !cmsUsersRepository.existsById(id);
	}

}
