package com.freshdesk.controller;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.freshdesk.entity.CmsUsers;
import com.freshdesk.entity.Groups;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
public class GroupsPermissionsInput {
	private Boolean upload;
    private Boolean editDelete;
    private Boolean view;
    private Boolean approveReject;

	
}
