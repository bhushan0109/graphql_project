package com.freshdesk.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.freshdesk.entity.Groups;
import com.freshdesk.entity.GroupsPermissions;
import com.freshdesk.repository.GroupsRepository;
import com.freshdesk.security.HeaderValidator;
import com.freshdesk.security.RequiresAuthentication;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class GroupsController {
	@Autowired
	private HttpServletRequest httpServletRequest;
	private final HeaderValidator headerValidator;

	public GroupsController(HeaderValidator headerValidator) {
		this.headerValidator = headerValidator;
	}

	@Autowired
	private GroupsRepository groupsRepository;


	@QueryMapping
	public List<Groups> getAllGroups() {
		return groupsRepository.findAll();
	}

	@QueryMapping
	public Optional<Groups> getGroupById(@Argument Long id) {
		return groupsRepository.findById(id);
	}

	@MutationMapping
	public Groups createGroup(@Argument String name, @Argument Boolean archive,
			@Argument GroupsPermissionsInput groupsPermissionsInput) {
		GroupsPermissions permissions = new GroupsPermissions(groupsPermissionsInput.getUpload(),
				groupsPermissionsInput.getEditDelete(), groupsPermissionsInput.getView(),
				groupsPermissionsInput.getApproveReject());
		Groups group = new Groups(name, archive, permissions);
		return groupsRepository.save(group);
	}

	@MutationMapping
	public Groups updateGroup(@Argument Long id, @Argument String name, @Argument Boolean archive,
			@Argument GroupsPermissionsInput groupsPermissionsInput) {
		Groups group = groupsRepository.findById(id).orElseThrow();
		if (name != null)
			group.setName(name);
		if (archive != null)
			group.setArchive(archive);
		if (groupsPermissionsInput != null) {
			GroupsPermissions permissions = new GroupsPermissions(groupsPermissionsInput.getUpload(),
					groupsPermissionsInput.getEditDelete(), groupsPermissionsInput.getView(),
					groupsPermissionsInput.getApproveReject());
			group.setGroupsPermissions(permissions);
		}
		return groupsRepository.save(group);
	}

	@MutationMapping
	public boolean deleteGroup(@Argument Long id) {
		groupsRepository.deleteById(id);
		return !groupsRepository.existsById(id);
	}

	@QueryMapping
	public String whitelistedQuery() {
		return "This query is whitelisted";
	}

	@RequiresAuthentication
	@QueryMapping
	public String securedQuery() {
		return "This query requires authentication";
	}

}
