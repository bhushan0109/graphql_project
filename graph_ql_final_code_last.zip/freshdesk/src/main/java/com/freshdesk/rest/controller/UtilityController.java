package com.freshdesk.rest.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.freshdesk.utility.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/util")
@CrossOrigin(origins = { "*" })
public class UtilityController {
	private static final Logger logger = LoggerFactory.getLogger(UtilityController.class);

	@Value("${running.vm.name}")
	private String vmName;

	@GetMapping()
	// @RateLimiter(name = "blinkxApi", fallbackMethod = "rateLimitingFallback")
	public ResponseEntity<String> runtest(HttpServletRequest httpRequest) {
		String value = "FreshdeskApplication test1 is running successfully On vm name is " + vmName
				+ " and user ip is=> " + CommonUtil.getClientIp(httpRequest);
		return ResponseEntity.ok(value);

	}

	@GetMapping("/log")
	public String log() {
		String requestId = MDC.get("requestId");
		logger.info("Handling request with ID: " + requestId);
		return "Request logged with ID: " + requestId;
	}
}