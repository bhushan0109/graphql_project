package com.freshdesk.utility;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.http.HttpServletRequest;

public class CommonUtil {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonUtil.class);
	private static String LOCALHOST_IPV4 = "127.0.0.1";
	private static String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS = "SUCCESS";
	public static final String SOMETHING_WENT_WRONG = "Internal Server Error";

	public static void exceptionLog(Exception e) {
		LOGGER.error("Exception :  ", e);
	}

	public static Boolean isNullOrEmpty(String string) {
		return (string == null || string.isEmpty() || string.length() == 0);
	}

	public static String trim(String string) {
		if (!isNullOrEmpty(string)) {
			return string.trim();
		}
		return null;
	}

	public static String captializeAllFirstLetter(String str) {
		String trimName = str.trim();
		String words[] = trimName.split("\\s");
		String capitalizeStr = "";

		for (String word : words) {
			if (word.isEmpty()) {
				continue;
			}
			// Capitalize first letter
			String firstLetter = word.substring(0, 1);
			// Get remaining letter
			String remainingLetters = word.substring(1).toLowerCase();
			capitalizeStr += firstLetter.toUpperCase() + remainingLetters + " ";
		}
		System.out.println(capitalizeStr);

		return capitalizeStr.trim();
	}

	public static CommonResponse newErrorResponse(Exception e, String userId, String mobileNumber)
			throws JsonMappingException, JsonProcessingException {
		ObjectMapper objectMapper = new ObjectMapper();
		LOGGER.info("FailResponse fail util userId,mobileNumber ==>" + userId + " _ " + mobileNumber);
		ErrorCodeEnum errorCodeEnum = ErrorCodeEnum.findByValue(e.getMessage());
		if (errorCodeEnum != null) {
			return new CommonResponse(errorCodeEnum.getId(), errorCodeEnum.getValue(), null);
		} else {
			CommonUtil.exceptionLog(e);
		}
//		if (e instanceof WebClientResponseException) {
//			HttpStatusCode statusCode = ((WebClientResponseException) e).getStatusCode();
//			LOGGER.info("fail WebClientResponseException status code==>" + statusCode.value());
//			String responseBodyAsString = ((WebClientResponseException) e).getResponseBodyAsString();
//			LOGGER.info("WebClientResponseException responseBodyAsString ==>" + responseBodyAsString);
//
//		}
//		if (e instanceof CustomException) { // <-- How to convert string to exception class
//			CustomException customException = ((CustomException) e);
//			LOGGER.info("MiddleWareFailResponse CustomException fail status code==>" + customException.status_code);
//			if (customException.status_code != 200) {
//				return new CommonResponse(customException.status_code, customException.message, null);
//			} else {
//				return new CommonResponse(customException.status_code, "Access token is not valid", null);
//			}
//		}

		return new CommonResponse(ErrorCodeEnum.EXCEPTION_OCCURRED.getId(), ErrorCodeEnum.EXCEPTION_OCCURRED.getValue(),
				null);

	}

	public static String getClientIp(HttpServletRequest request) {
		String ipAddress = request.getHeader("X-Forwarded-For");
		if (request != null || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}

		if (request != null || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}

		if (request != null || "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
				try {
					InetAddress inetAddress = InetAddress.getLocalHost();
					ipAddress = inetAddress.getHostAddress();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
			}
		}

		if ((request != null) && ipAddress.length() > 15 && ipAddress.indexOf(",") > 0) {
			ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
		}
		return ipAddress;
	}

	public static boolean checkFileExtension(String fileExtension) {
		boolean result = false;
		if (!fileExtension.isEmpty()) {

			String[] extensionList = { "png", "jpg", "jpeg", "wepb" };
			for (String extension : extensionList) {
				if (fileExtension.equalsIgnoreCase(extension)) {
					result = true;
					return result;
				}
			}
		}
		return result;
	}

}