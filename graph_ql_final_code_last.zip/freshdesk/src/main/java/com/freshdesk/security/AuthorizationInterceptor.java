//package com.freshdesk.config;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//import org.springframework.web.method.HandlerMethod;
//import org.springframework.web.servlet.HandlerInterceptor;
//import org.springframework.web.servlet.ModelAndView;
//
//import jakarta.servlet.http.HttpServletRequest;
//import jakarta.servlet.http.HttpServletResponse;
//
//@Component
//public class AuthorizationInterceptor implements HandlerInterceptor {
//
//	@Autowired
//	private HeaderValidator headerValidator;
//
//	@Override
//	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
//			throws Exception {
//
//		String authHeader = request.getHeader("Authorization");
//		if (authHeader == null || !headerValidator.validateAuthorizationHeader(authHeader)) {
//			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
//			return false;
//		}
//		return true;
//	}
//
////    @Override
////    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
////    	 if (handler instanceof HandlerMethod) {
////            HandlerMethod handlerMethod = (HandlerMethod) handler;
////            RequiresAuthentication annotation = handlerMethod.getMethodAnnotation(RequiresAuthentication.class);
////            if (annotation != null) {
////                String authHeader = request.getHeader("Authorization");
////                if (authHeader == null || !headerValidator.validateAuthorizationHeader(authHeader)) {
////                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
////                    return false;
////                }
////            }
////    	 }
////        return true;
////    }
//
//	@Override
//	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
//			ModelAndView modelAndView) throws Exception {
//		// This method is not used in this example but can be implemented if needed
//	}
//
//	@Override
//	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
//			throws Exception {
//		// This method is not used in this example but can be implemented if needed
//	}
//}


