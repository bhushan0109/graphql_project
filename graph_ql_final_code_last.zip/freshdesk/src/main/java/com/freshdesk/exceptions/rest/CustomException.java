package com.freshdesk.exceptions.rest;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

@AllArgsConstructor
@RequiredArgsConstructor
public class CustomException extends Exception {

	private static final long serialVersionUID = 1L;

	public Integer status_code;
	public String message;

}
