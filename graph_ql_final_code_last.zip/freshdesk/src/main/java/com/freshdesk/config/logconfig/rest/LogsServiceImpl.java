package com.freshdesk.config.logconfig.rest;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.freshdesk.utility.CommonUtil;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Service
public class LogsServiceImpl implements LogsService {

	@Autowired
	private ObjectMapper objectMapper;

	private static final Logger logger = LoggerFactory.getLogger(LogsServiceImpl.class);

	@Override
	public void displayReq(HttpServletRequest request, Object body) throws JsonProcessingException {
		StringBuilder reqMessage = new StringBuilder();
		Map<String, String> parameters = getParameters(request);

		reqMessage.append("REQUEST ");
		reqMessage.append("method = [").append(request.getMethod()).append("]");
		reqMessage.append(" path = [").append(request.getRequestURI()).append("] ");
		reqMessage.append("from IP = [").append(CommonUtil.getClientIp(request)).append("] ");

		if (!parameters.isEmpty()) {
			reqMessage.append(" parameters = [").append(parameters).append("] ");
		}

		if (!Objects.isNull(body)) {
			reqMessage.append(" body = [").append(body).append("]");
			logger.info("Request body from ip >" + CommonUtil.getClientIp(request) + " "
					+ objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));
		}
		logger.info(
				"Request body final " + objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(reqMessage));
	}

	@Override
	public void displayResp(HttpServletRequest request, HttpServletResponse response, Object body)
			throws JsonProcessingException {
		try {
			logger.info("Response body for ip >" + CommonUtil.getClientIp(request) + " "
					+ objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(body));
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	private Map<String, String> getParameters(HttpServletRequest request) {
		Map<String, String> parameters = new HashMap<>();
		Enumeration<String> params = request.getParameterNames();
		while (params.hasMoreElements()) {
			String paramName = params.nextElement();
			String paramValue = request.getParameter(paramName);
			parameters.put(paramName, paramValue);
		}
		return parameters;
	}

}
