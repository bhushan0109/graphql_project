package com.freshdesk.config.logconfig.rest;

import com.fasterxml.jackson.core.JsonProcessingException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public interface LogsService {

    void displayReq(HttpServletRequest request, Object body) throws JsonProcessingException;

    void displayResp(HttpServletRequest request, HttpServletResponse response, Object body) throws JsonProcessingException;
}
