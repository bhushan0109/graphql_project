package com.freshdesk.graphql.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import com.freshdesk.entity.Groups;
import com.freshdesk.repository.GroupsRepository;
import com.freshdesk.security.RequiresAuthentication;
import com.freshdesk.service.GroupsPermissionsInput;
import com.freshdesk.service.GroupsResolver;

@Controller
public class GroupsController {

	@Autowired
	GroupsResolver groupsResolver;

	@Autowired
	private GroupsRepository groupsRepository;

	@QueryMapping
	public List<Groups> getAllGroups() {
		return groupsRepository.findAll();
	}

	@QueryMapping
	public Optional<Groups> getGroupById(@Argument Long id) {
		return groupsRepository.findById(id);
	}

	@MutationMapping
	public Groups createGroup(@Argument String name, @Argument Boolean archive,
			@Argument GroupsPermissionsInput groupsPermissionsInput) {

		Groups group = groupsResolver.createGroup(name, archive, groupsPermissionsInput);

		return group;
	}

	@MutationMapping
	public Groups updateGroup(@Argument Long id, @Argument String name, @Argument Boolean archive,
			@Argument GroupsPermissionsInput groupsPermissionsInput) {

		Groups group = groupsResolver.updateGroup(id, name, archive, groupsPermissionsInput);

		return group;

	}

	@MutationMapping
	public boolean deleteGroup(@Argument Long id) {
		groupsRepository.deleteById(id);
		return !groupsRepository.existsById(id);
	}

	@QueryMapping
	public String whitelistedQuery() {
		return "This query is whitelisted";
	}

	@RequiresAuthentication
	@QueryMapping
	public String securedQuery() {
		return "This query requires authentication";
	}

}
