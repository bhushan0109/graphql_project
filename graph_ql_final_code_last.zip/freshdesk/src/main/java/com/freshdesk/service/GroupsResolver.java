package com.freshdesk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.freshdesk.entity.Groups;
import com.freshdesk.entity.GroupsPermissions;
import com.freshdesk.repository.GroupsPermissionsRepository;
import com.freshdesk.repository.GroupsRepository;

@Component
public class GroupsResolver {

	@Autowired
	private GroupsRepository groupsRepository;

	@Autowired
	private GroupsPermissionsRepository groupsPermissionsRepository;

	public List<Groups> getAllGroups() {
		return groupsRepository.findAll();
	}

	public Optional<Groups> getGroupById(Long id) {
		return groupsRepository.findById(id);
	}

	public Groups createGroup(String name, Boolean archive, GroupsPermissionsInput groupsPermissionsInput) {

		GroupsPermissions permissions = new GroupsPermissions(groupsPermissionsInput.getUpload(),
				groupsPermissionsInput.getEditDelete(), groupsPermissionsInput.getView(),
				groupsPermissionsInput.getApproveReject());
		Groups group = new Groups(name, archive, permissions);
		return groupsRepository.save(group);
	}

	public Groups updateGroup(Long id, String name, Boolean archive, GroupsPermissionsInput groupsPermissionsInput) {
		Groups group = groupsRepository.findById(id).orElseThrow();
		if (name != null)
			group.setName(name);
		if (archive != null)
			group.setArchive(archive);
		if (groupsPermissionsInput != null) {
			GroupsPermissions permissions = new GroupsPermissions(groupsPermissionsInput.getUpload(),
					groupsPermissionsInput.getEditDelete(), groupsPermissionsInput.getView(),
					groupsPermissionsInput.getApproveReject());
			group.setGroupsPermissions(permissions);
		}
		return groupsRepository.save(group);
	}

	public boolean deleteGroup(Long id) {
		groupsRepository.deleteById(id);
		return !groupsRepository.existsById(id);
	}
}
