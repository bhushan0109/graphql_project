package com.freshdesk.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.freshdesk.entity.CmsUsers;
import com.freshdesk.entity.Groups;
import com.freshdesk.exceptions.graphql.CustomException;
import com.freshdesk.exceptions.graphql.ErrorCode;
import com.freshdesk.repository.CmsUsersRepository;
import com.freshdesk.repository.GroupsRepository;

@Component
public class CmsUsersResolver {

	@Autowired
	private CmsUsersRepository cmsUsersRepository;

	@Autowired
	private GroupsRepository groupsRepository;

	public List<CmsUsers> getAllCmsUsers() {
		return cmsUsersRepository.findAll();
	}

	public Optional<CmsUsers> getCmsUserById(Long id) {
		return cmsUsersRepository.findById(id);
	}

	public CmsUsers createCmsUser(String name, String email, Boolean isActive, Long groupId) {
		Groups group = groupsRepository.findById(groupId)
				.orElseThrow(() -> new CustomException(ErrorCode.GROUP_NOT_FOUND,
						ErrorCode.GROUP_NOT_FOUND.getMessage() + " _ " + groupId));
		CmsUsers cmsUser = new CmsUsers(name, email, isActive, group);
		return cmsUsersRepository.save(cmsUser);
	}

	public CmsUsers updateCmsUser(Long id, String name, String email, Boolean isActive, Long groupId) {
		CmsUsers cmsUser = cmsUsersRepository.findById(id).orElseThrow(
				() -> new CustomException(ErrorCode.USER_NOT_FOUND, ErrorCode.USER_NOT_FOUND.getMessage() + " _" + id));
		if (name != null)
			cmsUser.setName(name);
		if (email != null)
			cmsUser.setEmail(email);
		if (isActive != null)
			cmsUser.setIsActive(isActive);
		if (groupId != null) {
			Groups group = groupsRepository.findById(groupId)
					.orElseThrow(() -> new CustomException(ErrorCode.GROUP_NOT_FOUND,
							ErrorCode.GROUP_NOT_FOUND.getMessage() + " _" + groupId));
			cmsUser.setGroups(group);
		}
		return cmsUsersRepository.save(cmsUser);
	}
	public boolean deleteCmsUser(Long id) {
		cmsUsersRepository.deleteById(id);
		return !cmsUsersRepository.existsById(id);
	}
}
